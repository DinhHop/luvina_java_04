package bai03;

public class KiemTraSach{
	public static void main(String[]agrs){
		TacGia t = new TacGia("DVH", "dvhopptit@gmail.com", "thong tin tac gia");
		Sach s = new Sach("Java", t, 123, 22);
		System.out.print(s.toString());
	}
	
}
