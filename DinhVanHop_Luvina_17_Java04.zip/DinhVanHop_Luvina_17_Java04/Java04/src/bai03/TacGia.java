package bai03;

public class TacGia {
	private String ten;
	private String email;
	private String thonhTinTacGia;
	public TacGia(String ten, String email, String thonhTinTacGia) {
		super();
		this.ten = ten;
		this.email = email;
		this.thonhTinTacGia = thonhTinTacGia;
	}
	
	public String toString(){
		return "Ten tac gia: " + ten
				+"\nEmail: " + email
				+"\nThong tin tac gia: " + thonhTinTacGia;
	}
	
}
