package bai05;

public class HinhTronDiChuyen extends GiaoDienDiChuyen {
	
	DiemDiChuyen r;
	DiemDiChuyen tam;
	
	public HinhTronDiChuyen(DiemDiChuyen r, DiemDiChuyen tam) {
		super();
		this.r = r;
		this.tam = tam;
	}

	@Override
	public void diLen() {
		
	}

	@Override
	public void diXuong() {
		
	}

	@Override
	public void sangTrai() {
		
	}

	@Override
	public void sangPhai() {
		
	}

	@Override
	public String toString() {
		return "HinhTronDiChuyen [r=" + r.toString() + "\ntam=" + tam.toString() + "]";
	}
	
	
	
}
