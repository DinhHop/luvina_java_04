package bai05;

public class DiemDiChuyen extends GiaoDienDiChuyen {
	private int x;
	private int y;
	private int vx;
	private int vy;
	public DiemDiChuyen(int x, int y, int vx, int vy) {
		super();
		this.x = x;
		this.y = y;
		this.vx = vx;
		this.vy = vy;
	}
	
	
	@Override
	public String toString() {
		return "DiemDiChuyen [x=" + x + ", y=" + y + ", vx=" + vx + ", vy=" + vy + "]";
	}

	@Override
	public void diLen() {
		
	}

	@Override
	public void diXuong() {
		
	}

	@Override
	public void sangTrai() {
		
	}

	@Override
	public void sangPhai() {
		
	}
}
