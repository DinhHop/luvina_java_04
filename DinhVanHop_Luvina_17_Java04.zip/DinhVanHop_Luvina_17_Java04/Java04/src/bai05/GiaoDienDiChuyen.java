package bai05;

public abstract class GiaoDienDiChuyen {
	public abstract void diLen();
	
	public abstract void diXuong();
	
	public abstract void sangTrai();
	
	public abstract void sangPhai();
}
