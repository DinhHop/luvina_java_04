package bai02;

public class KiemTraTamGiac {
	public static void main(String []agrs){
		Diem d1 = new Diem(1, 1);
		Diem d2 = new Diem(2, 2);
		Diem d3 = new Diem(3, 4);
		TamGiac t = new TamGiac(d1, d2, d3);
		System.out.print(t.toString());
	}
}
