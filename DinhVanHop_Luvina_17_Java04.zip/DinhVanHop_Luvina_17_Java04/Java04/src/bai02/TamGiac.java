package bai02;

import java.text.DecimalFormat;

public class TamGiac {
	private Diem diem1;
	private Diem diem2;
	private Diem diem3;
	public TamGiac(int x1, int y1, int x2, int y2, int x3, int y3){
		diem1.setX(x1);
		diem1.setY(y1);
		diem2.setX(x2);
		diem2.setY(y2);
		diem3.setX(x3);
		diem3.setY(y3);
	}
	
	public TamGiac(Diem d1, Diem d2, Diem d3){
		this.diem1 = d1;
		this.diem2 = d2;
		this.diem3 = d3;
	}
	
	public boolean kiemTraTamGiac(Diem d1, Diem d2, Diem d3){
		if((d1.khoangCach(d2) + d2.khoangCach(d3))> d1.khoangCach(d3)
		&& (d1.khoangCach(d2) + d1.khoangCach(d3))> d2.khoangCach(d3)
		&& (d1.khoangCach(d3) + d2.khoangCach(d3))> d1.khoangCach(d2)){
			return true;
		}
		return false;
	}
	
	//Công thức tính diện tích biết 3 cạnh
	// sqrt ((a+b+c)(a+b-c)(b+c-a)(c+a-b))/4
	public float dienTichTamGiac(Diem d1, Diem d2, Diem d3){
		return (float)Math.sqrt((d1.khoangCach(d2) + d2.khoangCach(d3)+ d3.khoangCach(d1))
				* (d1.khoangCach(d2) + d2.khoangCach(d3)- d3.khoangCach(d1))
				* (d1.khoangCach(d2) + d3.khoangCach(d1)- d2.khoangCach(d3))
				* (d2.khoangCach(d3)+ d3.khoangCach(d1))-(d1.khoangCach(d2)))/4;
	}
	
	public String toString(){
		
		String str = "";
		if(kiemTraTamGiac(diem1, diem2, diem3) == true){
			DecimalFormat df = new DecimalFormat("0.00");
			String s = df.format(dienTichTamGiac(diem1, diem2, diem3));
			float result = Float.parseFloat(s);
			str ="3 diem nay co tao thanh tam giac" + "\nDien tich tam giac la: " + result;
		}
		else{
			str = "3 diem nay khong tao thanh tam giac";
		}
		return str;
	}
}
